var n=0;
var showNum = document.getElementById("num");
function Mea(value){
	n=value;
	setBg(value);
	plays(value);
	}
function setBg(value){
	for(var i=0;i<4;i++)
   if(value==i){
		showNum.getElementsByTagName("td")[i].className='woon';
		} 
	else{	
		showNum.getElementsByTagName("td")[i].className='wooff';
		}  
	} 
function plays(value){
	with (fc){
		filters[0].Apply();
		for(i=0;i<4;i++)i==value?children[i].style.display="block":children[i].style.display="none"; 
		filters[0].play(); 		
		}	
}
function clearAuto(){clearInterval(autoStart)}
function setAuto(){autoStart=setInterval("auto(n)", 5000)}
function auto(){
	n++;
	if(n>3)n=0;
	Mea(n);
} 
function sub(){
	n--;
	if(n<0)n=3;
	Mea(n);
} 
setAuto(); 