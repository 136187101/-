<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @version $Id: innobase.lib.php 10137 2007-03-19 17:55:39Z cybot_tm $
 */

/**
 *
 */
include_once './libraries/engines/innodb.lib.php';

/**
 *
 */
class PMA_StorageEngine_innobase extends PMA_StorageEngine_innodb {}

?>
