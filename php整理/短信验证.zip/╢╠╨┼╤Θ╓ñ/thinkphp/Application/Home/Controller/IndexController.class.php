<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function register(){
		/* 显示注册页面 */
		$this->display();
    }

	public function send_tel()
	{	
		$username='phzb';
		$password='123456';
		$phones=$_POST['phones'];
		$contents=$_POST['code'].'【磐和资本】';
		$_SESSION['code'] = $_POST['code'];	//将js生成验证码存在session中
		$scode='';
		$setTime='';
		//$contents=urldecode(iconv('gb2312','utf-8',$contents)); //进行UTF-8转码
		$srv_ip = 'yyqd.shareagent.cn';  //你的目标服务地址或频道
		$srv_port = 888; 
		$url = '/sdk/Service.asmx/sendMessage'; //接收你post的URL具体地址   
		$fp = '';  
		$resp_str = '';  
		$errno = 0;  
		$errstr = ''; 
		$timeout = 10;
		$post_str = "username=".$username."&pwd=".$password."&phones=".$phones."&contents=".$contents."&scode=".$scode."&setTime=".$setTime;
		$err='';
		if ($srv_ip == '' || $url == '')
		{  
		 $err='ip or dest url empty</br>'; 
		}
		$fp = fsockopen($srv_ip,$srv_port,$errno,$errstr,$timeout);  
		if (!$fp){$err.='fp fail</br>';  }	
		$content_length = strlen($post_str); 
		$post_header = "POST $url HTTP/1.1\r\n"; 
		$post_header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$post_header .= "User-Agent: MSIE\r\n";
		$post_header .= "Host: ".$srv_ip."\r\n";  
		$post_header .= "Content-Length: ".$content_length."\r\n";
		$post_header .= "Connection: close\r\n\r\n"; 
		$post_header .= $post_str."\r\n\r\n"; 
		fwrite($fp,$post_header); 
		 $inheader = 1;  
		while(!feof($fp)){ 
		$line=fgets($fp,512);
		 if ($inheader && ($line == "\n" || $line == "\r\n")) { 
			 $inheader = 0; 
		} 
		if ($inheader == 0) { 
		$resp_str .= $line;//返回值放入$resp_str 
		}
		}
		$bodytag = trim($resp_str);	
		fclose($fp); 

		$dom = new \DOMDocument('1.0');
		$dom ->loadXML($bodytag);
		$xml = simplexml_import_dom($dom);

		//var_dump($xml);die;
		$res= $xml;
		unset ($resp_str);
		if($res=='1'){
			echo '发送成功,请注意查收';
		}else{
			echo '发送失败,请确认您的手机号码是否正确，请保持网络通常';
		}
	}

	function register_do()
	{
		if($_SESSION['code'] == $_POST['yzm'])//验证码验证
		{
			/* 执行添加 */
			print_r($_POST);
			session_unset($_SESSION['code']);//消除
		}else
		{
			$this->error('验证码不正确');//不消除session中的code可以再输入一次
		}
	}
	

}