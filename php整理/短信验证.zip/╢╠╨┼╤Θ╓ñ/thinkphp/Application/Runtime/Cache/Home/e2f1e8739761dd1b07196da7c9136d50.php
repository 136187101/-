<?php if (!defined('THINK_PATH')) exit();?><html>
	<head>
		<title>欢迎注册</title>
		<script src="/thinkphp/Public/JS/jquery-1.9.1.min.js" type="text/javascript"></script>
	</head>
<body>
	<form method="post" action="<?php echo U('Index/register_do');?>" onsubmit="return check_form()">
			姓名：<input type="text" name="username" id="username"><p>
			手机号码：<input type="text" name="tel" id="tel"><input id="btnSendCode" type="button" value="发送验证码" onclick="sendMessage()" /></p>
			验证码:<input type="text" name="yzm" id="yzm"><p>
			<input type="submit" value="提交">
		</form>	
</body>
    <script type="text/javascript">
	//验证表单
		function check_form()
		{
			var username = $("#username").val();
			if(username=='')
			{
				alert('姓名不能为空');
				return false;
			}
			
				var phones = $("#tel").val();
			
				var preg_phones = '/^[0-9]{11}$/';
				if(!preg_phones.test(phones))
				{
					alert('手机号码必须为11位纯数字并且1开头');
					return false;
				}
			
/*
			var yzm = $("#yzm").val();
			if(yzm!='')
			{
				var preg_yzm = '/^\d{6}$/';
				if(!preg_yzm.test(yzm))
				{
					alert('验证码必须为6位纯数字');
					return false;
				}
			}else
			{
				alert('验证码不能为空');
				return false;
			}
			//alert(username);
			*/
		}


        var InterValObj; //timer变量，控制时间
		var count = 10; //间隔函数，1秒执行
		var curCount;//当前剩余秒数
		var code = ""; //验证码
		var codeLength = 6;//验证码长度
		function sendMessage() {
			curCount = count;
			//产生验证码
			for (var i = 0; i < codeLength; i++) {
                code += parseInt(Math.random() * 9).toString();
            }
			//获取手机号码
			var phones = $("#tel").val();
			if(phones!='')
			{
            //设置button效果，开始计时
                $("#btnSendCode").attr("disabled", "true");
                $("#btnSendCode").val("请在" + curCount + "秒内输入验证码");
                InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
			//向后台发送处理数据
                $.ajax({
                    type: "POST", //用POST方式传输
                    dataType: "text", //数据格式:JSON
                    url: "<?php echo U('Index/send_tel');?>", //目标地址
                    data: "phones=" + phones + "&code=" + code,
                    error: function (XMLHttpRequest, textStatus, errorThrown) { },
                    success: function (msg){ 
						alert(msg);
					}
                });
				return true;
			}else
			{
				alert('手机号码不能为空');
				return false;
			}
         }
        //timer处理函数
		function SetRemainTime() {
            if (curCount == 0) {               
                window.clearInterval(InterValObj);//停止计时器
                $("#btnSendCode").removeAttr("disabled");//启用按钮
                $("#btnSendCode").val("重新发送验证码");
                code = ""; //清除验证码。如果不清除，过时间后，输入收到的验证码依然有效    
            }
            else {
                curCount--;
                $("#btnSendCode").val("请在" + curCount + "秒内输入验证码");
            }
        }
    </script>
</html>